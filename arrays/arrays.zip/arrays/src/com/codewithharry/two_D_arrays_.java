package com.codewithharry;

public class two_D_arrays_ {
    public static void main(String[] args) {
        int A[][]=new int [7][5];
//        for (int i=0;i<A.length;i++){
//            for (int j=0;j<A[0].length;j++){
//                System.out.print(A[i][j]);
//            }
//            System.out.println();
//        }

//        int A[][]={{1,2,3},{2,3,4},{4,3,2},{2,3,4}};
//        for (int i=0;i<A.length;i++){
//            for (int j=0;j<A[0].length;j++){
//                System.out.print(A[i][j]);
//            }
//            System.out.println();
//        }

//        int A[][]={{1,2,3},{2,3,4},{4,3,2},{2,3,4 }};
//        for (int x[]:A){
//            for (int y:x){
//                System.out.print(y+" ");
//            }
//            System.out.println();
//        }

    }
}
