package com.codewithharry;

public class rotating_an_arrays_left_side {
    public static void main(String[] args) {
        int A[]={3,9,7,8,12,6,30,5,4,10};
        for (int x:A)
            System.out.print(x+",");
        int temp=A[0];
        for (int i=1;i<A.length;i++){
            A[i-1]=A[i];
        }A[A.length-1]=temp;
        for (int x:A)
            System.out.print(x+",");

    }
}
