package com.codewithharry;

public class shorting_string_array {
    public static void main(String[] args) {
        String arr[] = {"java", "python", "pascal", "ada", "Ayush"};
        java.util.Arrays.sort(arr);
        for (String x : arr) {

            System.out.print(x + " ");
        }
        System.out.println();

    }

}
