package com.codewithharry;

public class subarray_in_arrays {
    public static void main(String args[]){
        int [] a={-10,0,20,30,22,0,-1,40};
//
        int [] subArray1=new int[1];


        for (int i : subArray1)

            System.out.println(i + "  ");

        int [] subArray2=new int[3];
        System.arraycopy(a, 2, subArray2, 0, 3);
        for (int i : subArray2)

            System.out.print(i + "  ");

        int [] subArray3=new int[2];
        System.arraycopy(a, 6, subArray3, 0, 2);
        for (int i : subArray3)

            System.out.println(i + " ");
    }
}
