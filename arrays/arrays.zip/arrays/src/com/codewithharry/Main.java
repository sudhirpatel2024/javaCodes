package com.codewithharry;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {


//        int [] a={-10,0,20,30,22,0,-1,40};
//        int [] subArray2=new int[3];
//
//        System.arraycopy(a, 3, subArray2, 0, 2);
//        for (int i : subArray2)
//            System.out.print(i + "  ");
//
//        int [] subArray3=new int[2];
//        System.arraycopy(a, 3, subArray3, 0, 2);
//        for (int i : subArray3)
//            System.out.print(i + "  ");



//        int[] a = new int[] {-10,0,20,30,22,0,-1,40};
//        int[] b = new int[4];
//        System.arraycopy(a, 3, b, 0, 4);
//        for (int i : b)
//            System.out.print(i + "  ");


   }
}









































